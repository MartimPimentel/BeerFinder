/*
 * Copyright (c) 2015-present, Parse, LLC.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */
package com.parse.starter;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.parse.LogInCallback;
import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseAnonymousUtils;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.util.ArrayList;


public class InicializerActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

  ArrayList<String> availableCities = new ArrayList<>();
  String selectedCity = "";

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    setTitle("Where is The Beer?");

    /**
     * Adding cities(possibility to add to Parse when more cities become available.
     */
    availableCities.add("Lisbon");

    Spinner spinner = (Spinner) findViewById(R.id.dropDownSpinner);

    ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,availableCities);
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    spinner.setAdapter(adapter);
    spinner.setOnItemSelectedListener(this);

    ParseAnalytics.trackAppOpenedInBackground(getIntent());
  }

  @Override
  public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
    selectedCity = adapterView.getItemAtPosition(i).toString();
  }

  @Override
  public void onNothingSelected(AdapterView<?> adapterView) {}

  public void goToChosenCity(View view){
    if (!selectedCity.equals("")){
      Intent intent = new Intent(getApplicationContext(),SelectedCityActivity.class);
      intent.putExtra("chosenCity",selectedCity);
      startActivity(intent);
    }else{
      Toast.makeText(this,"Select a city from the dropdown menu",Toast.LENGTH_SHORT);
    }
  }

}

