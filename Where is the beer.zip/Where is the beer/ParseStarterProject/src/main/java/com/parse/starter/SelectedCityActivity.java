package com.parse.starter;

import android.*;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SelectedCityActivity extends AppCompatActivity {
    String selectedCity;
    ListView barsListView;
    LocationManager locationManager;
    LocationListener locationListener;
    Location actualLocation;
    SimpleAdapter simpleAdapter;
    final List<Map<String,String>> data = new ArrayList<>();

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_menu,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(getApplicationContext(),InicializerActivity.class);
        startActivity(intent);

        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_city);


        Intent intent = getIntent();
        selectedCity = intent.getStringExtra("chosenCity");



        setTitle(selectedCity);

        barsListView = findViewById(R.id.barsListView);

        getLocation();

        simpleAdapter = new SimpleAdapter(this,data,android.R.layout.simple_list_item_2,
                new String[]{"barName","barDistance"}, new int[]{android.R.id.text1,android.R.id.text2});

        barsListView.setAdapter(simpleAdapter);

        //updateBars();

        barsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),BarDescriptionActivity.class);
                intent.putExtra("barName",data.get(i).get("barName"));
                intent.putExtra("currentLatitude", Double.toString(actualLocation.getLatitude()));
                intent.putExtra("currentLongitude", Double.toString(actualLocation.getLongitude()));
                intent.putExtra("chosenCity",selectedCity);
                startActivity(intent);
            }
        });

        final Handler handler = new Handler();
        Runnable run = new Runnable() {
            @Override
            public void run() {
                if (actualLocation!=null) {
                    updateBars();
                }
                //updates open bars every 10 minutes
                handler.postDelayed(this,600000);
            }
        };
        handler.post(run);
    }

    public void updateListView(final Location location){
        final ParseQuery<ParseObject> query = ParseQuery.getQuery(selectedCity);

        ArrayList<String> currentListedSpots = new ArrayList<>();
        for (int i=0; i<data.size();i++){
            currentListedSpots.add(data.get(i).get("barName"));
        }

        query.whereContainedIn("BarName",currentListedSpots);

        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {

                if (e == null){

                    if ( objects.size() > 0){
                        int i=0;
                        for (ParseObject object : objects){
                            ParseGeoPoint currentLocation = new ParseGeoPoint(location.getLatitude(), location.getLongitude());
                            ParseGeoPoint barLocation = (ParseGeoPoint) object.get("BarLocation");
                            if (barLocation != null) {
                                Double distanceInKm = currentLocation.distanceInKilometersTo(barLocation);

                                Double distanceOneDP = (double) Math.round(distanceInKm * 10) / 10;

                                data.get(i).put("barDistance",distanceOneDP.toString() + "km");

                            }
                            i++;
                        }
                    }
                    simpleAdapter.notifyDataSetChanged();
                }
            }
        });

    }


    public void updateBars(){
        ParseUser.logOut();
        ParseQuery<ParseObject> query = ParseQuery.getQuery(selectedCity);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        final String currentTime = format.format(calendar.getTime());
        final String[] currentTimeArray = currentTime.split(":",2);

        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null){

                    if ( objects.size() > 0){
                        data.clear();
                        //info.clear();
                        for (ParseObject object : objects){
                            Map<String,String> info = new HashMap<>();
                            String closingTime = object.getString("BarClosingHour");
                            String openingTime = object.getString("BarOpeningHour");

                            String[] closingTimeArray = closingTime.split(":",2);
                            String[] openingTimeArray = openingTime.split(":",2);
                            int openingHour = Integer.parseInt(openingTimeArray[0]);
                            int openingMin = Integer.parseInt(openingTimeArray[1]);
                            int closingHour =Integer.parseInt(closingTimeArray[0]);
                            int closingMin =Integer.parseInt(closingTimeArray[1]);
                            int currentHour =Integer.parseInt(currentTimeArray[0]);
                            int currentMin =Integer.parseInt(currentTimeArray[1]);

                            if (closingHour>=24 && currentHour<12){
                                currentHour +=24;
                            }

                            if ((openingHour< currentHour || ((openingHour== currentHour) && openingMin< currentMin)) && (closingHour> currentHour || (closingHour== currentHour && closingMin> currentMin))){

                                ParseGeoPoint currentLocation = new ParseGeoPoint(actualLocation.getLatitude(), actualLocation.getLongitude());
                                ParseGeoPoint barLocation = (ParseGeoPoint) object.get("BarLocation");
                                if (barLocation != null) {
                                    info.put("barName", object.getString("BarName"));

                                    Double distanceInKm = currentLocation.distanceInKilometersTo(barLocation);
                                    Double distanceOneDP = (double) Math.round(distanceInKm * 10) / 10;

                                    info.put("barDistance", distanceOneDP.toString() + "km");

                                }

                                data.add(info);
                            }

                        }

                        simpleAdapter.notifyDataSetChanged();
                    }
                }else{
                    e.printStackTrace();
                }

            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);

                    Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                    actualLocation= lastKnownLocation;
                    updateBars();
                    //updateListView(lastKnownLocation);
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    public void getLocation(){
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                if (!(location.getLongitude()==actualLocation.getLongitude() && actualLocation.getLatitude() == location.getLatitude())){

                    actualLocation = location;
                    updateListView(location);
                }
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };

        if (Build.VERSION.SDK_INT < 23) {

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);


        }else{
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){

                ActivityCompat.requestPermissions(this, new String[] {android.Manifest.permission.ACCESS_FINE_LOCATION},1);

            }else{

                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,locationListener);

                Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                if (lastKnownLocation != null){
                    if (actualLocation ==null) {
                        actualLocation = lastKnownLocation;
                        updateBars();
                    }else{
                        actualLocation = lastKnownLocation;
                    }
                    //updateListView(lastKnownLocation);
                }
            }
        }
    }

    public void goBackButton(View view){
        finish();
    }


}

