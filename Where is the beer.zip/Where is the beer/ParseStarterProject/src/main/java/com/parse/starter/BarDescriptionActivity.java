package com.parse.starter;

import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.List;

public class BarDescriptionActivity extends AppCompatActivity {
    TextView barNameTextView;
    TextView openingHoursTextView;
    TextView closingHoursTextView;
    TextView[] beerPricesTextView;
    int numberAvailableBeers= 3;
    String currentLatitude;
    String currentLongitude;
    String barLatitude;
    String barLongitude;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_menu,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(getApplicationContext(),InicializerActivity.class);
        startActivity(intent);

        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_description);

        setTitle("Where is The Beer?");


        beerPricesTextView = new TextView[numberAvailableBeers];

        barNameTextView = findViewById(R.id.barNameTextView);
        openingHoursTextView = findViewById(R.id.openingHoursTextView);
        closingHoursTextView = findViewById(R.id.closingHoursTextView);
        for (int i=1; i<=numberAvailableBeers;i++){
            int id = BarDescriptionActivity.this.getResources().getIdentifier("beertype_"+ Integer.toString(i), "id", getPackageName());
            beerPricesTextView[i-1] = (TextView) findViewById(id);
        }


        Intent intent = getIntent();
        String barName = intent.getStringExtra("barName");
        String chosenCity = intent.getStringExtra("chosenCity");
        currentLatitude = intent.getStringExtra("currentLatitude");
        currentLongitude = intent.getStringExtra("currentLongitude");

        ParseQuery<ParseObject> query = ParseQuery.getQuery(chosenCity);

        query.whereEqualTo("BarName",barName);

        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null){
                    if (objects.size() > 0){
                        for (ParseObject object : objects) {

                            ParseGeoPoint barLocation = (ParseGeoPoint) object.get("BarLocation");
                            barLatitude = Double.toString(barLocation.getLatitude());
                            barLongitude = Double.toString(barLocation.getLongitude());


                            barNameTextView.setText(object.getString("BarName"));
                            openingHoursTextView.setText(object.getString("BarOpeningHour"));
                            String barClosingHours = object.getString("BarClosingHour");

                            String[] closingTimeArray = barClosingHours.split(":",2);
                            int closingHour =Integer.parseInt(closingTimeArray[0]);
                            int closingMin =Integer.parseInt(closingTimeArray[1]);
                            if (closingHour >= 24){
                                closingHour -=24;
                                String stringClosingHour = Integer.toString(closingHour);
                                if (closingHour < 10){
                                    stringClosingHour = "0" + stringClosingHour;
                                }
                                String stringClosingMin = Integer.toString(closingMin);
                                if (closingMin<10){
                                    stringClosingMin = "0" + stringClosingMin;
                                }
                                barClosingHours = stringClosingHour + ":" + stringClosingMin;
                            }
                            closingHoursTextView.setText(barClosingHours);

                            List<String> barPrices = object.getList("BarPrices");

                            for (int i=0; i<barPrices.size();i++){
                                if (barPrices.get(i).equals("-")){
                                    beerPricesTextView[i].setText("---");
                                }else{
                                    beerPricesTextView[i].setText(barPrices.get(i) + "€");
                                }
                            }


                        }
                    }
                }else {
                    e.printStackTrace();
                }
            }
        });
    }

    public void goBackFunction(View view){
        finish();
    }

    public void getDirectionsButton(View view){

        Intent directionsIntent = new Intent(android.content.Intent.ACTION_VIEW,
                Uri.parse("http://maps.google.com/maps?saddr=" + currentLatitude +
                        "," + currentLongitude + "&daddr=" + barLatitude +
                        "," + barLongitude));
        startActivity(directionsIntent);
    }
}






















